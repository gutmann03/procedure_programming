//
// Developed by Volodymyr Smetaniuk on 16.10.22.
//

#pragma once

double ArithGeomAverage(double, double);
