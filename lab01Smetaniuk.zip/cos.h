// Developed by Smetaniuk on 23.09.2022

#pragma once

double myCos(double, double);