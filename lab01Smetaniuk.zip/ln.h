// Developed by Smetaniuk on 22.09.2022

#pragma once

double myLn(double, double);