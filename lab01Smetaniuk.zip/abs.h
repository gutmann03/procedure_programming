// Developed by Smetaniuk 22.09.2022

#pragma once

double abs(double);