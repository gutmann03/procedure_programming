// Developed by Smetaniuk on 23.09.2022

double abs(double value) {
	return value < 0 ? -value : value;
}