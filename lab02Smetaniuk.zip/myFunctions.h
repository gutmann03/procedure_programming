//
// Developed by Volodymyr Smetaniuk on 02.10.2022.

#pragma once

double myPower(double, int, int&);
double myQuickPow(double, int, int&);
double myRecPow(double, int, int&);