// Developed by Smetaniuk on 22.09.2022

#pragma once

double mySum(int n, double x);