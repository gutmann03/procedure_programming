// Developed by Smetaniuk on 22.09.2022

#pragma once

int divideWithTheRemainder(int divisible, int divisor);