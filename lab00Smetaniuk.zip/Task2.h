// Developed by Smetaniuk on 22.09.2022

#pragma once

double mySin(double x, double epsilon);