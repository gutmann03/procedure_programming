// Developed by Smetaniuk on 22.09.2022

#pragma once

int GCD_Loop(int value1, int value2);
int GCD_Recursive(int value1, int value2);