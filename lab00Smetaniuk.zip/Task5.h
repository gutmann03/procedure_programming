// Developed by Smetaniuk on 22.09.2022

#pragma once

double funcChebyshev(unsigned int n, double x);